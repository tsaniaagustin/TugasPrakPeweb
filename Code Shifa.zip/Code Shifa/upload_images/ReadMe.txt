Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/post-to-facebook-wall-from-website-php-sdk/

============ Installation ============
1. Open the fbConfig.php file and specify the $appId, $appSecret, and $redirectURL as per your Facebook App credentials.
5. Browse the index.php file in the browser and test the Post to Facebook Wall functionality

============ May I Help You ===========
If you have any query about this script, send the query by post a comment here - http://www.codexworld.com/post-to-facebook-wall-from-website-php-sdk/#respond